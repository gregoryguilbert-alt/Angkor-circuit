import { test } from "node:test";
import assert from "node:assert/strict";
import { estimateTempleMinutes } from "../client/src/lib/duration.ts";
import {
  temples,
  itineraryPresets,
  siemReapActivities,
  circuitOrder,
  circuitMeta,
} from "../client/src/lib/angkor-data.ts";

test("durées de visite converties correctement", () => {
  const cases: [string, number][] = [
    ["2–3 h", 150],
    ["2–3 h le groupe", 150],
    ["45–75 min", 60],
    ["50–80 min", 65],
    ["1 h 30", 90],
    ["Demi-journée A/R", 240],
    ["1 journée", 480],
    ["15–20 min", 18],
    ["60–90 min", 75],
    ["30 min", 30],
    ["Variable", 30],
  ];
  for (const [input, expected] of cases) {
    assert.equal(estimateTempleMinutes(input), expected, input);
  }
});

test("chaque temple a un identifiant unique et un circuit valide", () => {
  const ids = temples.map((t) => t.id);
  assert.equal(new Set(ids).size, ids.length, "identifiants en double");
  for (const temple of temples) {
    assert.ok(temple.circuits.length > 0, `${temple.id} sans circuit`);
    for (const circuit of temple.circuits) {
      assert.ok(circuitOrder.includes(circuit), `${temple.id} : circuit inconnu ${circuit}`);
    }
    assert.ok(temple.name && temple.summary, `${temple.id} : nom ou résumé manquant`);
  }
});

test("coordonnées dans la zone d'Angkor et de Siem Reap", () => {
  // Zone large : inclut Beng Mealea (env. 60 km à l'est) et Kbal Spean (nord)
  const inZone = (c: { lat: number; lng: number }) => c.lat > 13.0 && c.lat < 14.0 && c.lng > 103.5 && c.lng < 104.6;
  for (const temple of temples) {
    assert.ok(inZone(temple.coords), `${temple.id} hors zone`);
  }
  for (const activity of siemReapActivities) {
    assert.ok(inZone(activity.coords), `${activity.id} hors zone`);
  }
});

test("itinéraires : durées de visite définies et circuits cohérents", () => {
  for (const [days, plan] of Object.entries(itineraryPresets)) {
    assert.ok(plan.length > 0, `${days} jour(s) sans étape`);
    for (const day of plan) {
      assert.ok(day.temples.length > 0, `jour ${day.day} sans temple`);
      for (const temple of [...day.temples, ...(day.optionalTemples ?? [])]) {
        assert.match(temple.duration, /\d|journée/i, `${temple.id} : durée sans valeur (« ${temple.duration} »)`);
      }
    }
  }
  assert.ok(circuitMeta.petit.label);
});
