# Module Angkor Circuit Guide — checkpoint 717809c1

Cette archive contient la version restaurée du guide interactif Angkor au checkpoint `717809c1`. Elle peut être utilisée comme application autonome ou comme base d’intégration dans un site principal.

## Contenu

- `client/src/pages/Home.tsx` : interface principale du guide.
- `client/src/lib/angkor-data.ts` : temples, circuits, itinéraires, activités et traductions.
- `client/src/components/Map.tsx` : composant cartographique fourni par le projet.
- `client/src/index.css` : identité visuelle et responsive.
- `client/src/components/ui/` : composants UI utilisés par le guide.
- `package.json` et `pnpm-lock.yaml` : dépendances et scripts de build.

Les dossiers `node_modules`, `dist`, `.git` et les journaux temporaires ne sont pas inclus.

## Utilisation autonome

```bash
pnpm install
pnpm dev
```

Pour une version de production :

```bash
pnpm check
pnpm build
pnpm start
```

## Intégration dans un site principal

### Option recommandée : intégration par iframe

Construire et déployer ce module comme une application autonome, puis l’insérer dans la page du site principal :

```html
<iframe
  src="URL_DE_L_APPLICATION_ANGKOR"
  title="Guide interactif d’Angkor"
  loading="lazy"
  style="display:block;width:100%;min-height:1200px;border:0"
></iframe>
```

Cette option conserve les interactions du guide : carte, géolocalisation, fiches temples, itinéraires, météo et activités de Siem Reap.

### Option source : intégration React directe

1. Copier `client/src/pages/Home.tsx` dans une route de la nouvelle application, par exemple `/angkor`.
2. Copier `client/src/lib/angkor-data.ts` et les composants UI utilisés.
3. Importer les styles de `client/src/index.css`, ou reprendre les tokens et classes nécessaires.
4. Conserver les dépendances listées dans `package.json`, notamment `react`, `react-dom`, `lucide-react`, `wouter`, `sonner`, `framer-motion` et les paquets Radix utilisés.
5. Vérifier l’alias TypeScript `@/*` si le site principal utilise une configuration différente.
6. Monter `Home` dans la route souhaitée :

```tsx
import Home from "./pages/Home";

export function AngkorModule() {
  return <Home />;
}
```

## Carte et géolocalisation

`Map.tsx` utilise l’intégration cartographique disponible dans l’environnement Manus. Pour une intégration hors Manus, remplacer `MapView` par le fournisseur cartographique du site principal et conserver l’API attendue par `Home.tsx` (`onMapReady`, centre initial et zoom). La géolocalisation navigateur reste soumise à HTTPS et à l’autorisation de l’utilisateur.

## Point de restauration

- Checkpoint demandé : `717809c1`
- Commit de rollback local : `1f5f3dd`
- Version validée avec `pnpm check` et `pnpm build` le 30 octobre 2026.

## Variables d’environnement

Définir ces variables au moment du build (fichier `.env` local ou configuration de l’hébergeur) :

- `VITE_FRONTEND_FORGE_API_KEY` : clé utilisée pour charger Google Maps via le proxy.
- `VITE_FRONTEND_FORGE_API_URL` : adresse du proxy Google Maps.
- `VITE_GOOGLE_MAP_ID` : identifiant de carte Google. Sans cette variable, l’identifiant de démonstration `DEMO_MAP_ID` est utilisé et un avertissement apparaît en console.
- `VITE_ANALYTICS_ENDPOINT` et `VITE_ANALYTICS_WEBSITE_ID` : facultatifs. Si elles sont absentes, aucun script d’analytique n’est chargé.

Les clés ne doivent jamais être versionnées. Le fichier de configuration de l’environnement de développement a été retiré de cette archive : ses valeurs doivent être régénérées puis saisies dans l’hébergeur.

## Tests

```bash
pnpm test
```

Les tests vérifient les conversions de durée, l’unicité des identifiants de temples, les coordonnées (zone d’Angkor et de Siem Reap) et la présence des durées dans les itinéraires.
