import { createRoot } from "react-dom/client";
import App from "./App";
import "./index.css";

// Analytique (Umami) : chargée seulement si l'environnement la configure,
// pour éviter une requête cassée sur un déploiement autonome.
const analyticsEndpoint = import.meta.env.VITE_ANALYTICS_ENDPOINT;
const analyticsWebsiteId = import.meta.env.VITE_ANALYTICS_WEBSITE_ID;
if (analyticsEndpoint && analyticsWebsiteId) {
  const script = document.createElement("script");
  script.defer = true;
  script.src = `${analyticsEndpoint}/umami`;
  script.dataset.websiteId = analyticsWebsiteId;
  document.body.appendChild(script);
}

createRoot(document.getElementById("root")!).render(<App />);
