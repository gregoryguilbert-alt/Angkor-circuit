import { useEffect, useMemo, useRef, useState } from "react";
import { MapView } from "@/components/Map";
import {
  ArrowDownRight,
  ArrowUpRight,
  BookOpen,
  Check,
  ChevronRight,
  Clock3,
  Compass,
  Download,
  ExternalLink,
  Footprints,
  Info,
  ListChecks,
  LocateFixed,
  LocateOff,
  MapPinned,
  Menu,
  Navigation,
  Plus,
  Route,
  Search,
  Share2,
  Sparkles,
  Sun,
  Users,
  Utensils,
  X,
} from "lucide-react";
import {
  circuitMeta,
  circuitOrder,
  getItinerary,
  getImage,
  grandRoute,
  languages,
  petitRoute,
  practicalPanels,
  siemReapActivities,
  fallbackWeather,
  weatherRecommendation,
  temples,
  translations,
  type Circuit,
  type SiemReapActivity,
  type Temple,
} from "@/lib/angkor-data";
import { estimateTempleMinutes } from "@/lib/duration";

const navItems = [
  { href: "#map", translation: "map", fallback: "Carte", icon: MapPinned },
  { href: "#itinerary", translation: "itinerary", fallback: "Itinéraire", icon: Route },
  { href: "#temples", translation: "temples", fallback: "Temples", icon: BookOpen },
  { href: "#experiences", translation: "experiences", fallback: "Mais pas que…", icon: Compass },
  { href: "#practical", translation: "practical", fallback: "Pratique", icon: Info },
  { href: "#beyond", translation: "beyond", fallback: "Plus loin", icon: ArrowUpRight },
];

const colorMap: Record<string, string> = {
  jade: "var(--jade)", terracotta: "var(--terracotta)", gold: "var(--gold)", forest: "#3b7355", blue: "#466b86",
};

function distanceBetween(a: { lat: number; lng: number }, b: { lat: number; lng: number }) {
  const earthRadiusKm = 6371;
  const toRadians = (value: number) => value * Math.PI / 180;
  const dLat = toRadians(b.lat - a.lat);
  const dLng = toRadians(b.lng - a.lng);
  const latA = toRadians(a.lat);
  const latB = toRadians(b.lat);
  const haversine = Math.sin(dLat / 2) ** 2 + Math.cos(latA) * Math.cos(latB) * Math.sin(dLng / 2) ** 2;
  const kilometers = earthRadiusKm * 2 * Math.atan2(Math.sqrt(haversine), Math.sqrt(1 - haversine));
  return kilometers < 1 ? `${Math.round(kilometers * 1000)} m` : `${kilometers.toFixed(1)} km`;
}

function formatEstimatedDuration(minutes: number) {
  const hours = Math.floor(minutes / 60);
  const remainder = minutes % 60;
  if (!hours) return `${remainder} min`;
  if (!remainder) return `${hours} h`;
  return `${hours} h ${String(remainder).padStart(2, "0")}`;
}

function ImageFallback({ temple, className = "" }: { temple: Temple; className?: string }) {
  return (
    <img
      src={getImage(temple, 1000)}
      alt={temple.name}
      className={className}
      loading="lazy"
      onError={(event) => {
        event.currentTarget.style.display = "none";
        event.currentTarget.parentElement?.classList.add("image-failed");
      }}
    />
  );
}

function CircuitIcon({ circuit }: { circuit: Circuit }) {
  if (circuit === "sunset") return <Sun size={17} strokeWidth={1.8} />;
  if (circuit === "beng") return <Sparkles size={17} strokeWidth={1.8} />;
  if (circuit === "plus") return <ArrowUpRight size={17} strokeWidth={1.8} />;
  return <Route size={17} strokeWidth={1.8} />;
}

export default function Home() {
  type RouteMode = "light" | "balanced" | "complete" | "custom";
  const [activeCircuit, setActiveCircuit] = useState<Circuit>("petit");
  const [stayDays, setStayDays] = useState(2);
  const [optionalItineraryIds, setOptionalItineraryIds] = useState<string[]>([]);
  const [routeMode, setRouteMode] = useState<RouteMode>("light");
  const [weather, setWeather] = useState(fallbackWeather);
  const [weatherLoading, setWeatherLoading] = useState(false);
  const [visitHour, setVisitHour] = useState(() => new Date().getHours());
  const [mapMode, setMapMode] = useState<"filter" | "all" | "petit" | "grand">("filter");
  const [selected, setSelected] = useState<string[]>(() => {
    try { return JSON.parse(localStorage.getItem("angkor-selection") || "[]"); } catch { return []; }
  });
  const [detail, setDetail] = useState<Temple | null>(null);
  const [activityDetail, setActivityDetail] = useState<SiemReapActivity | null>(null);
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [language, setLanguage] = useState("fr");
  const [mobileNav, setMobileNav] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [mapReady, setMapReady] = useState(false);
  const [locationState, setLocationState] = useState<"idle" | "locating" | "active" | "denied" | "error">("idle");
  const [locationAccuracy, setLocationAccuracy] = useState<number | null>(null);
  const [userCoords, setUserCoords] = useState<{ lat: number; lng: number } | null>(null);
  const mapRef = useRef<google.maps.Map | null>(null);
  const locationWatchRef = useRef<number | null>(null);
  const locationMarkerRef = useRef<google.maps.marker.AdvancedMarkerElement | null>(null);
  const centeredOnLocationRef = useRef(false);
  const markersRef = useRef<google.maps.marker.AdvancedMarkerElement[]>([]);
  const activityMarkersRef = useRef<google.maps.marker.AdvancedMarkerElement[]>([]);
  const routesRef = useRef<google.maps.Polyline[]>([]);
  const templeRefs = useRef<Record<string, HTMLElement | null>>({});

  const t = translations[language] || translations.fr;
  const visibleTemples = useMemo(() => {
    const source = temples.filter((temple) => temple.circuits.includes(activeCircuit));
    if (!searchQuery.trim()) return source;
    const query = searchQuery.toLowerCase();
    return source.filter((temple) => `${temple.name} ${temple.khmer} ${temple.style}`.toLowerCase().includes(query));
  }, [activeCircuit, searchQuery]);
  const beyondTemples = temples.filter((temple) => temple.circuits.includes("plus"));
  const itinerary = useMemo(() => getItinerary(stayDays), [stayDays]);
  const weatherTip = useMemo(() => weatherRecommendation(visitHour, weather), [visitHour, weather]);

  const optionalIdsForMode = (mode: Exclude<RouteMode, "custom">) => {
    const options = itinerary.flatMap((day) => day.optionalTemples || []);
    if (mode === "light") return [];
    if (mode === "complete") return options.map((temple) => temple.id);
    return itinerary.flatMap((day) => (day.optionalTemples || []).slice(0, 1).map((temple) => temple.id));
  };

  useEffect(() => {
    if (routeMode !== "custom") setOptionalItineraryIds(optionalIdsForMode(routeMode));
  }, [stayDays, routeMode]);

  const refreshWeather = async () => {
    setWeatherLoading(true);
    try {
      const response = await fetch("https://api.open-meteo.com/v1/forecast?latitude=13.3633&longitude=103.8561&current=temperature_2m,relative_humidity_2m,apparent_temperature,precipitation_probability,wind_speed_10m&timezone=Asia%2FPhnom_Penh");
      if (!response.ok) throw new Error("weather");
      const data = await response.json();
      const current = data.current || {};
      setWeather({ temperature: Math.round(current.temperature_2m ?? fallbackWeather.temperature), feelsLike: Math.round(current.apparent_temperature ?? fallbackWeather.feelsLike), condition: (current.precipitation_probability ?? 0) >= 50 ? "Risque d’averse" : "Peu de pluie attendue", rainChance: Math.round(current.precipitation_probability ?? fallbackWeather.rainChance), humidity: Math.round(current.relative_humidity_2m ?? fallbackWeather.humidity), wind: Math.round(current.wind_speed_10m ?? fallbackWeather.wind), source: "local" });
    } catch {
      setWeather(fallbackWeather);
    } finally {
      setWeatherLoading(false);
    }
  };

  // Charge la météo réelle dès l'ouverture ; sans réponse, les valeurs indicatives restent signalées.
  useEffect(() => {
    refreshWeather();
  }, []);

  useEffect(() => {
    localStorage.setItem("angkor-selection", JSON.stringify(selected));
  }, [selected]);

  useEffect(() => () => {
    if (locationWatchRef.current !== null) navigator.geolocation?.clearWatch(locationWatchRef.current);
    if (locationMarkerRef.current) locationMarkerRef.current.map = null;
  }, []);

  useEffect(() => {
    if (!mapReady || !mapRef.current || !window.google?.maps?.marker) return;
    markersRef.current.forEach((marker) => { marker.map = null; });
    activityMarkersRef.current.forEach((marker) => { marker.map = null; });
    routesRef.current.forEach((route) => { route.setMap(null); });
    markersRef.current = [];
    activityMarkersRef.current = [];
    routesRef.current = [];
    const markerTemples = mapMode === "all"
      ? temples
      : mapMode === "petit"
        ? temples.filter((temple) => temple.circuits.includes("petit"))
        : mapMode === "grand"
          ? temples.filter((temple) => temple.circuits.includes("grand"))
          : temples.filter((temple) => temple.circuits.includes(activeCircuit));

    markerTemples.forEach((temple) => {
      const pin = document.createElement("button");
      pin.className = `map-pin ${temple.secondary ? "pin-secondary" : `pin-${circuitMeta[temple.circuits[0]].tone}`}`;
      pin.setAttribute("aria-label", temple.name);
      pin.innerHTML = `<span>${temple.detour ? "✦" : ""}</span>`;
      pin.onclick = () => setDetail(temple);
      const marker = new google.maps.marker.AdvancedMarkerElement({
        map: mapRef.current,
        position: temple.coords,
        title: temple.name,
        content: pin,
      });
      markersRef.current.push(marker);
    });

    siemReapActivities.forEach((activity) => {
      const pin = document.createElement("button");
      pin.className = `activity-map-pin tone-${activity.tone}`;
      pin.setAttribute("aria-label", activity.title);
      pin.innerHTML = `<span>${activity.number}</span>`;
      pin.onclick = () => setActivityDetail(activity);
      const marker = new google.maps.marker.AdvancedMarkerElement({
        map: mapRef.current,
        position: activity.coords,
        title: activity.title,
        content: pin,
      });
      activityMarkersRef.current.push(marker);
    });

    if (mapMode === "all" || mapMode === "petit" || (mapMode === "filter" && ["petit", "sunset"].includes(activeCircuit))) {
      routesRef.current.push(new google.maps.Polyline({ map: mapRef.current, path: petitRoute, strokeColor: "#2d654b", strokeOpacity: 0.85, strokeWeight: 4 }));
    }
    if (mapMode === "all" || mapMode === "grand" || (mapMode === "filter" && ["grand", "sunset"].includes(activeCircuit))) {
      routesRef.current.push(new google.maps.Polyline({ map: mapRef.current, path: grandRoute, strokeColor: "#b85b3b", strokeOpacity: 0.85, strokeWeight: 4 }));
    }
  }, [activeCircuit, mapMode, mapReady]);

  const toggleSelected = (id: string) => {
    setSelected((current) => current.includes(id) ? current.filter((item) => item !== id) : [...current, id]);
  };

  const toggleItineraryOptional = (id: string) => {
    setRouteMode("custom");
    setOptionalItineraryIds((current) => current.includes(id) ? current.filter((item) => item !== id) : [...current, id]);
  };

  const applyRouteMode = (mode: Exclude<RouteMode, "custom">) => {
    setRouteMode(mode);
    setOptionalItineraryIds(optionalIdsForMode(mode));
  };

  const templesForDay = (day: (typeof itinerary)[number]) => [
    ...day.temples,
    ...(day.optionalTemples || []).filter((temple) => optionalItineraryIds.includes(temple.id)),
  ];
  const estimatedVisitMinutes = useMemo(() => itinerary.reduce((total, day) => total + templesForDay(day).reduce((dayTotal, temple) => dayTotal + estimateTempleMinutes(temple.duration), 0), 0), [itinerary, optionalItineraryIds]);
  const activeOptionalCount = optionalItineraryIds.filter((id) => itinerary.some((day) => day.optionalTemples?.some((temple) => temple.id === id))).length;

  const focusOnMap = (temple: Temple) => {
    document.querySelector("#map")?.scrollIntoView({ behavior: "smooth", block: "center" });
    if (mapRef.current) {
      mapRef.current.panTo(temple.coords);
      mapRef.current.setZoom(16);
    }
    setMapMode("all");
    setDetail(null);
  };

  const focusActivityOnMap = (activity: SiemReapActivity) => {
    setActivityDetail(null);
    document.querySelector("#map")?.scrollIntoView({ behavior: "smooth", block: "center" });
    setMapMode("all");
    window.setTimeout(() => {
      if (mapRef.current) {
        mapRef.current.panTo(activity.coords);
        mapRef.current.setZoom(15);
      }
    }, 250);
  };

  const toggleLocation = () => {
    if (locationWatchRef.current !== null) {
      navigator.geolocation.clearWatch(locationWatchRef.current);
      locationWatchRef.current = null;
      if (locationMarkerRef.current) locationMarkerRef.current.map = null;
      locationMarkerRef.current = null;
      centeredOnLocationRef.current = false;
      setLocationState("idle");
      setLocationAccuracy(null);
      setUserCoords(null);
      return;
    }
    if (!navigator.geolocation) {
      setLocationState("error");
      return;
    }
    setLocationState("locating");
    locationWatchRef.current = navigator.geolocation.watchPosition((position) => {
      const coords = { lat: position.coords.latitude, lng: position.coords.longitude };
      setUserCoords(coords);
      setLocationAccuracy(Math.round(position.coords.accuracy));
      setLocationState("active");
      if (!mapRef.current || !window.google?.maps?.marker) return;
      if (!locationMarkerRef.current) {
        const dot = document.createElement("span");
        dot.className = "user-location-dot";
        dot.setAttribute("aria-label", "Votre position");
        locationMarkerRef.current = new google.maps.marker.AdvancedMarkerElement({ map: mapRef.current, position: coords, title: "Votre position", content: dot });
      } else {
        locationMarkerRef.current.position = coords;
      }
      if (!centeredOnLocationRef.current) {
        mapRef.current.panTo(coords);
        mapRef.current.setZoom(15);
        centeredOnLocationRef.current = true;
      }
    }, (error) => {
      setLocationState(error.code === error.PERMISSION_DENIED ? "denied" : "error");
      locationWatchRef.current = null;
    }, { enableHighAccuracy: true, maximumAge: 5000, timeout: 15000 });
  };

  // Impression via un iframe masqué : pas de fenêtre pop-up, donc rien à bloquer.
  const exportSelection = () => {
    const escapeHtml = (value: string) => value.replace(/[&<>"']/g, (char) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[char] as string);
    const chosen = temples.filter((temple) => selected.includes(temple.id));
    const items = chosen.map((temple) => `<li><strong>${escapeHtml(temple.name)}</strong> — ${escapeHtml(temple.duration)} · ${escapeHtml(temple.period)}<br><small>${escapeHtml(temple.summary)}</small></li>`).join("");
    const html = `<!doctype html><html lang="${escapeHtml(language)}"><head><meta charset="utf-8"><title>${escapeHtml(t.selection)}</title><style>body{font-family:Arial,sans-serif;padding:40px;color:#1d2a22}h1{font-size:28px}li{margin:12px 0}small{color:#637166}</style></head><body><h1>${escapeHtml(t.selection)}</h1><p>Angkor Circuit Guide · ${new Date().toLocaleDateString()}</p><ol>${items}</ol><p>${escapeHtml(t.footer)}</p></body></html>`;
    const frame = document.createElement("iframe");
    frame.setAttribute("aria-hidden", "true");
    frame.style.cssText = "position:fixed;right:0;bottom:0;width:0;height:0;border:0;";
    frame.onload = () => {
      frame.contentWindow?.focus();
      frame.contentWindow?.print();
      window.setTimeout(() => frame.remove(), 1000);
    };
    frame.srcdoc = html;
    document.body.appendChild(frame);
  };

  const scrollTo = (href: string) => {
    setMobileNav(false);
    document.querySelector(href)?.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <div className="app-shell">
      <header className="site-header">
        <div className="header-inner">
          <a href="#top" className="brand" onClick={() => setMobileNav(false)}>
            <span className="brand-mark">A<span>↗</span></span>
            <span className="brand-copy"><strong>Angkor</strong><small>{t.brandSub}</small></span>
          </a>
          <nav className={`desktop-nav ${mobileNav ? "mobile-open" : ""}`}>
            {navItems.map(({ href, translation, fallback, icon: Icon }) => <a key={href} href={href} onClick={() => setMobileNav(false)}><Icon size={15} />{t[translation] || fallback}</a>)}
          </nav>
          <div className="header-actions">
            <label className="language-select"><span>{t.lang}</span><select value={language} onChange={(event) => setLanguage(event.target.value)} aria-label={t.lang}>{languages.map((item) => <option key={item.value} value={item.value}>{item.label}</option>)}</select></label>
            <button className="selection-pill" onClick={() => setDrawerOpen(true)}><ListChecks size={16} /><span>{t.selection}</span><b>{selected.length}</b></button>
            <button className="icon-button mobile-menu" aria-label="Menu" onClick={() => setMobileNav((open) => !open)}><Menu size={20} /></button>
          </div>
        </div>
      </header>

      <main id="top">
        <section className="hero-section">
          <div className="hero-grid page-width">
            <div className="hero-copy">
              <div className="eyebrow"><span className="eyebrow-line" />{t.heroKicker}<span className="eyebrow-dot">✦</span></div>
              <h1>{t.heroTitle}</h1>
              <p className="hero-lead">{t.heroLead}</p>
              <div className="hero-actions">
                <button className="primary-button" onClick={() => scrollTo("#temples")}>Explorer les temples <ArrowDownRight size={17} /></button>
                <button className="ghost-button light" onClick={() => scrollTo("#map")}><MapPinned size={17} /> Ouvrir la carte</button>
              </div>
              <div className="hero-stats"><div><strong>17 km</strong><span>Petit circuit</span></div><div><strong>26 km</strong><span>Grand circuit</span></div><div><strong>37 · 62 · 72</strong><span>Pass 1·3·7 j, USD</span></div></div>
            </div>
            <div className="hero-art">
              <div className="hero-image-frame"><img src={commonsHero} alt="Angkor Wat au lever du jour" /><div className="hero-image-shade" /><div className="image-caption"><span>01</span><div><strong>La pierre dans la lumière</strong><small>Le ciel change, le temple aussi.</small></div></div></div>
              <div className="hero-note note-top"><Compass size={15} /><span>Field note</span><strong>Go east first</strong></div>
              <div className="hero-note note-bottom"><span className="note-number">07:30</span><span>heures douces</span><ArrowUpRight size={15} /></div>
            </div>
          </div>
          <div className="hero-bottom page-width"><span>Une sélection éditoriale pour marcher, regarder et choisir son rythme.</span><div className="scroll-hint"><span>Faire défiler</span><div className="scroll-line" /></div></div>
        </section>

        <section className="circuit-section page-width" aria-label="Choisir un circuit">
          <div className="section-intro-row"><div><div className="eyebrow dark"><span className="eyebrow-line" />Votre journée</div><h2>Choisissez un fil rouge.</h2></div><p>Un premier filtre pour faire émerger les bons temples — et laisser le reste pour une prochaine lumière.</p></div>
          <div className="circuit-tabs">{circuitOrder.map((circuit, index) => { const meta = circuitMeta[circuit]; const active = activeCircuit === circuit; return <button key={circuit} className={`circuit-tab ${active ? "active" : ""}`} onClick={() => { setActiveCircuit(circuit); setMapMode("filter"); }} style={{ "--accent": colorMap[meta.tone] } as React.CSSProperties}><span className="tab-index">0{index + 1}</span><span className="tab-icon"><CircuitIcon circuit={circuit} /></span><span className="tab-copy"><strong>{meta.label}</strong><small>{meta.short}</small></span><ChevronRight size={16} className="tab-arrow" /></button>; })}</div>
          <div className="circuit-description"><div className="description-accent" style={{ background: colorMap[circuitMeta[activeCircuit].tone] }} /><div><strong>{circuitMeta[activeCircuit].label}</strong><span>{circuitMeta[activeCircuit].description}</span></div><span className="description-count">{visibleTemples.length} sites</span></div>
        </section>

        <section id="itinerary" className="planner-section page-width">
          <div className="planner-heading">
            <div><div className="eyebrow dark"><span className="eyebrow-line" />Votre itinéraire</div><h2>Combien de jours avez-vous&nbsp;?</h2><p>Un parcours éditorial qui répartit les grands sites sans transformer la visite en course contre la montre.</p></div>
            <div className="duration-switcher" role="group" aria-label="Durée du séjour">
              {[1, 2, 3].map((days) => <button key={days} className={stayDays === days ? "active" : ""} onClick={() => setStayDays(days)}><strong>{days}</strong><span>{days === 1 ? "jour" : "jours"}</span></button>)}
            </div>
          </div>
          <div className="route-modes" role="group" aria-label="Mode d’itinéraire"><div className="route-modes-copy"><span>Intensité de la journée</span><small>Présélectionner les étapes secondaires</small></div><div className="route-mode-buttons"><button className={routeMode === "light" ? "active" : ""} onClick={() => applyRouteMode("light")}><strong>Léger</strong><small>Essentiels uniquement</small></button><button className={routeMode === "balanced" ? "active" : ""} onClick={() => applyRouteMode("balanced")}><strong>Équilibré</strong><small>Un détour par jour</small></button><button className={routeMode === "complete" ? "active" : ""} onClick={() => applyRouteMode("complete")}><strong>Complet</strong><small>Tous les secondaires</small></button></div></div>
          <div className="planner-summary"><div><span className="summary-label">Proposition pour</span><strong>{stayDays} {stayDays === 1 ? "jour" : "jours"} à Angkor</strong></div><div className="summary-rule" /><div className="summary-total"><span>Durée de visite estimée</span><strong>{formatEstimatedDuration(estimatedVisitMinutes)}</strong><small>{activeOptionalCount ? `${activeOptionalCount} étape${activeOptionalCount > 1 ? "s" : ""} secondaire${activeOptionalCount > 1 ? "s" : ""} incluse${activeOptionalCount > 1 ? "s" : ""}` : "Sans étape secondaire"}</small></div><span className="summary-note"><Sparkles size={15} /> Ajusté pour marcher, regarder et respirer.</span></div>
          <div className="itinerary-list">{itinerary.map((day) => { const dayTemples = templesForDay(day); return <article className="itinerary-day" key={day.day}><div className="day-marker"><span>0{day.day}</span><i /></div><div className="day-main"><div className="day-title-row"><div><span className="day-kicker">Jour {day.day} · {day.hours}</span><h3>{day.title}</h3><p>{day.subtitle}</p></div><span className="day-distance"><Footprints size={14} />{day.distance}</span></div><div className="day-temples">{dayTemples.map((temple) => <button key={temple.id} className={`day-temple ${temple.secondary ? "optional-added" : ""}`} onClick={() => setDetail(temple)}><span>{temple.name}{temple.secondary ? " · option" : ""}</span><small>{temple.duration}</small><ChevronRight size={14} /></button>)}</div>{day.optionalTemples?.length ? <div className="optional-stops"><div className="optional-stops-heading"><span><Plus size={13} />Étapes optionnelles</span><small>Ajoutez selon votre énergie</small></div><div className="optional-stop-list">{day.optionalTemples.map((temple) => { const active = optionalItineraryIds.includes(temple.id); return <button key={temple.id} className={`optional-stop ${active ? "active" : ""}`} onClick={() => toggleItineraryOptional(temple.id)} aria-pressed={active}><span>{active ? <Check size={13} /> : <Plus size={13} />}{temple.name}</span><small>{temple.duration}</small></button>; })}</div></div> : null}<div className="day-footer"><span><Info size={14} />{day.note}{day.optionalTemples?.length ? ` · ${day.optionalTemples.length} étapes secondaires disponibles` : ""}</span><button className="day-add" onClick={() => dayTemples.forEach((temple) => { if (!selected.includes(temple.id)) toggleSelected(temple.id); })}><ListChecks size={14} />Ajouter la journée</button></div></div></article>; })}</div>
        </section>

        <section id="weather" className="weather-section page-width">
          <div className="weather-panel">
            <div className="weather-main"><div className="eyebrow"><span className="eyebrow-line" />Météo à Siem Reap</div><div className="weather-reading"><Sun size={33} /><strong>{weather.temperature}°</strong><div><span>Ressenti {weather.feelsLike}°</span><b>{weather.condition}</b></div></div><button className="weather-refresh" onClick={refreshWeather}>{weatherLoading ? "Actualisation…" : weather.source === "local" ? "Actualisé maintenant" : "Voir la météo locale"} <ArrowUpRight size={14} /></button>{weather.source === "demo" && <small className="weather-demo-note">Valeurs indicatives : la météo en direct n’est pas disponible.</small>}</div>
            <div className="weather-stats"><div><span>Pluie</span><strong>{weather.rainChance}%</strong><small>probabilité</small></div><div><span>Humidité</span><strong>{weather.humidity}%</strong><small>air chargé</small></div><div><span>Vent</span><strong>{weather.wind} <small>km/h</small></strong><small>brise légère</small></div></div>
            <div className="weather-tip"><div className="weather-tip-heading"><Clock3 size={15} /><span>{weatherTip.label} · maintenant</span></div><strong>{weatherTip.title}</strong><p>{weatherTip.text}</p><span className="weather-sites">À privilégier · {weatherTip.sites}</span></div>
          </div>
          <div className="hour-selector"><div><span className="eyebrow dark"><span className="eyebrow-line" />Choisir une heure</span><p>Le conseil se recale sur votre heure de départ.</p></div><div className="hour-options">{[6, 9, 12, 15, 17].map((hour) => <button key={hour} className={visitHour === hour ? "active" : ""} onClick={() => setVisitHour(hour)}>{String(hour).padStart(2, "0")}h</button>)}</div></div>
        </section>

        <section id="map" className="map-section page-width">
          <div className="section-heading"><div><div className="eyebrow dark"><span className="eyebrow-line" />{t.map}</div><h2>Lire Angkor comme un paysage.</h2><p>{t.mapIntro}</p></div><div className="map-legend"><span><i className="legend-dot jade" />Petit circuit</span><span><i className="legend-dot terracotta" />Grand circuit</span><span><i className="legend-dot gold" />Coucher</span><span><i className="legend-dot secondary" />Temple secondaire</span></div></div>
          <div className="map-toolbar"><div className="toolbar-label"><Navigation size={16} /> Affichage</div>{["filter", "all", "petit", "grand"].map((mode) => <button key={mode} className={mapMode === mode ? "active" : ""} onClick={() => setMapMode(mode as typeof mapMode)}>{mode === "filter" ? circuitMeta[activeCircuit].label : mode === "all" ? "Tous les sites" : mode === "petit" ? "Petit circuit" : "Grand circuit"}</button>)}<button className={`location-button ${locationState === "active" ? "active" : ""}`} onClick={toggleLocation} aria-pressed={locationState === "active"}>{locationState === "denied" || locationState === "error" ? <LocateOff size={15} /> : <LocateFixed size={15} />}{locationState === "locating" ? "Localisation…" : "Ma position"}</button><button className="fit-button" onClick={() => { if (mapRef.current) { mapRef.current.setCenter({ lat: 13.44, lng: 103.89 }); mapRef.current.setZoom(13); } }}><Search size={15} /> Recadrer</button></div>
          <div className="map-card"><div className="map-canvas"><MapView className="angkor-google-map" initialCenter={{ lat: 13.44, lng: 103.89 }} initialZoom={13} onMapReady={(map) => { mapRef.current = map; setMapReady(true); }} /><div className="map-overlay-card"><span className="map-overlay-eyebrow">Selected route</span><strong>{circuitMeta[activeCircuit].label}</strong><div><span><Footprints size={13} />{activeCircuit === "petit" ? "17 km" : activeCircuit === "grand" ? "26 km" : "Selon l’étape"}</span><span><Clock3 size={13} />{activeCircuit === "beng" ? "1 journée" : "1 matinée"}</span></div></div><div className="map-compass"><span>N</span><Compass size={18} /></div></div><div className="map-footer"><div><span className="map-footer-label">À garder en tête</span><strong>La carte donne la distance. Votre énergie donne le rythme.</strong>{locationState === "active" && locationAccuracy !== null && <small className="location-accuracy">Position active · précision ±{locationAccuracy} m</small>}{locationState === "denied" && <small className="location-accuracy error">Autorisez la géolocalisation dans votre navigateur pour vous localiser.</small>}{locationState === "error" && <small className="location-accuracy error">Position indisponible pour le moment. Réessayez depuis un endroit dégagé.</small>}</div><a href="https://www.angkorenterprise.gov.kh/" target="_blank" rel="noreferrer">Vérifier les billets <ExternalLink size={14} /></a></div></div>
        </section>

        <section id="temples" className="temples-section page-width">
          <div className="section-heading temples-heading"><div><div className="eyebrow dark"><span className="eyebrow-line" />{t.temples}</div><h2>Les incontournables, sans la course.</h2><p>Ouvrez une fiche pour trouver l’entrée la plus calme, le meilleur moment et un chemin simple.</p></div><label className="search-box"><Search size={16} /><input value={searchQuery} onChange={(event) => setSearchQuery(event.target.value)} placeholder="Rechercher un temple" /></label></div>
          <div className="temple-grid">{visibleTemples.map((temple, index) => <TempleCard key={temple.id} temple={temple} index={index} selected={selected.includes(temple.id)} onOpen={() => setDetail(temple)} onToggle={() => toggleSelected(temple.id)} onMap={() => focusOnMap(temple)} ref={(element) => { templeRefs.current[temple.id] = element; }} t={t} />)}</div>
          {!visibleTemples.length && <div className="empty-state"><Search size={22} /><strong>Aucun temple trouvé</strong><span>Essayez un autre nom ou changez de circuit.</span></div>}
        </section>

        <section id="pause" className="info-section page-width"><InfoBand eyebrow="Pour tenir la journée" title={t.eat} intro="Le meilleur itinéraire laisse de la place à une pause. Quelques repères simples, sans prétendre remplacer votre curiosité." items={practicalPanels.eat} icon={<Utensils size={19} />} /></section>
        <section id="practical" className="info-section page-width"><InfoBand eyebrow="Avant de partir" title={t.practical} intro="Les détails qui rendent la visite plus fluide, plus confortable et plus respectueuse des lieux." items={practicalPanels.practical} icon={<Info size={19} />} /></section>
        <section id="advice" className="info-section page-width"><InfoBand eyebrow="Sur place" title={t.advice} intro="Angkor se découvre mieux quand on accepte de ralentir — et de changer de plan." items={practicalPanels.advice} icon={<Sparkles size={19} />} /></section>

        <section id="experiences" className="experiences-section page-width"><div className="section-heading experiences-heading"><div><div className="eyebrow dark"><span className="eyebrow-line" />Siem Reap, autrement</div><h2>Les temples, mais pas que…</h2><p>Une ville à goûter, à écouter et à parcourir doucement. Composez vos détours entre deux matins de pierre.</p></div><span className="section-icon"><Compass size={19} /></span></div><div className="experience-grid">{siemReapActivities.map((activity) => <article className={`experience-card tone-${activity.tone}`} key={activity.id}><div className="experience-image"><img src={activity.image} alt={activity.title} /><span>{activity.number}</span></div><div className="experience-body"><div className="experience-meta"><span>{activity.category}</span><b>{activity.bestTime}</b></div><h3>{activity.title}</h3><p>{activity.text}</p><div className="experience-detail"><button className="experience-open" onClick={() => setActivityDetail(activity)}>Ouvrir la fiche <ArrowUpRight size={14} /></button><button className="experience-map-link" onClick={() => focusActivityOnMap(activity)}><MapPinned size={13} /> Carte</button></div></div></article>)}</div></section>
        <section id="beyond" className="beyond-section page-width"><div className="beyond-intro"><div className="eyebrow dark"><span className="eyebrow-line" />{t.beyond}</div><h2>Une deuxième journée, peut-être.</h2><p>Au-delà des deux boucles centrales, les détours changent d’échelle : plus de route, plus de silence, parfois plus de marche.</p><button className="ghost-button" onClick={() => { setActiveCircuit("plus"); scrollTo("#temples"); }}>Voir les détours <ArrowUpRight size={17} /></button></div><div className="beyond-cards">{beyondTemples.map((temple, index) => <article className="beyond-card" key={temple.id} onClick={() => setDetail(temple)}><div className="beyond-image"><ImageFallback temple={temple} className="temple-image" /><span>0{index + 1}</span></div><div className="beyond-card-body"><div className="card-kicker">{temple.duration}</div><h3>{temple.name}</h3><p>{temple.summary}</p><span className="text-link">Ouvrir la fiche <ArrowUpRight size={14} /></span></div></article>)}</div></section>
      </main>

      <footer className="site-footer"><div className="footer-inner page-width"><div className="footer-brand"><span className="brand-mark">A<span>↗</span></span><div><strong>Angkor Circuit Guide</strong><p>{t.footer}</p><p className="footer-note">Tarifs et horaires rédigés en octobre 2026 : à confirmer avant le départ.</p></div></div><div className="footer-links"><a href="#top">Haut de page <ArrowUpRight size={14} /></a><a href="https://www.angkorenterprise.gov.kh/" target="_blank" rel="noreferrer">Angkor Enterprise <ExternalLink size={14} /></a></div></div></footer>

      {detail && <TempleModal temple={detail} selected={selected.includes(detail.id)} onClose={() => setDetail(null)} onToggle={() => toggleSelected(detail.id)} onMap={() => focusOnMap(detail)} t={t} />}
      {activityDetail && <ActivityModal activity={activityDetail} locationState={locationState} distance={userCoords ? distanceBetween(userCoords, activityDetail.coords) : null} onClose={() => setActivityDetail(null)} onMap={() => focusActivityOnMap(activityDetail)} onLocate={toggleLocation} />}
      {drawerOpen && <SelectionDrawer selected={selected} onClose={() => setDrawerOpen(false)} onToggle={toggleSelected} onClear={() => setSelected([])} onPrint={exportSelection} t={t} />}
    </div>
  );
}

const commonsHero = "https://commons.wikimedia.org/wiki/Special:FilePath/Angkor_Wat.jpg?width=1400";

type Translation = Record<string, string>;

type TempleCardProps = { temple: Temple; index: number; selected: boolean; onOpen: () => void; onToggle: () => void; onMap: () => void; t: Translation; ref?: (element: HTMLElement | null) => void };

function TempleCard({ temple, index, selected, onOpen, onToggle, onMap, t, ref }: TempleCardProps) {
  const tone = circuitMeta[temple.circuits[0]].tone;
  return <article className="temple-card" ref={ref} style={{ "--card-accent": temple.secondary ? "var(--secondary-temple)" : colorMap[tone], "--delay": `${index * 45}ms` } as React.CSSProperties}><div className="temple-photo"><ImageFallback temple={temple} className="temple-image" /><span className={`circuit-badge ${temple.secondary ? "secondary" : tone}`}>{temple.secondary ? "Temple secondaire" : temple.circuits.includes("sunset") ? "Sunset" : temple.circuits[0] === "plus" ? "Détour" : circuitMeta[temple.circuits[0]].label}</span><button className="photo-map-button" onClick={onMap} aria-label="Voir sur la carte"><MapPinned size={15} /></button></div><div className="temple-card-content"><div className="card-meta"><span>{temple.duration}</span><span>{temple.crowd}</span></div><h3>{temple.name}</h3><div className="khmer-name">{temple.khmer}</div><p>{temple.summary}</p><div className="card-bottom"><button className="text-link" onClick={onOpen}>{t.view} <ArrowUpRight size={14} /></button><button className={`add-button ${selected ? "selected" : ""}`} onClick={onToggle} aria-label={selected ? t.added : t.add}>{selected ? <Check size={16} /> : <Plus size={16} />}</button></div></div></article>;
}

function InfoBand({ eyebrow, title, intro, items, icon }: { eyebrow: string; title: string; intro: string; items: { title: string; text: string; tag: string }[]; icon: React.ReactNode }) {
  return <div className="info-band"><div className="section-heading info-heading"><div><div className="eyebrow dark"><span className="eyebrow-line" />{eyebrow}</div><h2>{title}</h2><p>{intro}</p></div><span className="section-icon">{icon}</span></div><div className="info-grid">{items.map((item, index) => <article className="info-card" key={item.title}><div className="info-card-top"><span>0{index + 1}</span><b>{item.tag}</b></div><h3>{item.title}</h3><p>{item.text}</p><ArrowUpRight size={17} className="info-arrow" /></article>)}</div></div>;
}

function TempleModal({ temple, selected, onClose, onToggle, onMap, t }: { temple: Temple; selected: boolean; onClose: () => void; onToggle: () => void; onMap: () => void; t: Translation }) {
  return <div className="modal-backdrop" role="dialog" aria-modal="true" aria-label={temple.name} onMouseDown={(event) => { if (event.target === event.currentTarget) onClose(); }}><div className="modal-sheet"><div className="modal-visual"><ImageFallback temple={temple} className="temple-image" /><div className="modal-visual-shade" /><button className="modal-close" onClick={onClose} aria-label={t.close}><X size={19} /></button><div className="modal-title"><span>{temple.secondary ? "Temple secondaire" : circuitMeta[temple.circuits[0]].label}</span><h2>{temple.name}</h2><small>{temple.khmer}</small></div></div><div className="modal-body"><div className="fact-grid"><Fact icon={<Clock3 />} label="Durée" value={temple.duration} /><Fact icon={<Users />} label="Affluence" value={temple.crowd} /><Fact icon={<Sun />} label="Lumière" value={temple.light} /><Fact icon={<Compass />} label="Style" value={temple.style} /></div><div className="entry-note"><div className="entry-note-heading"><Navigation size={16} /><strong>Entrées & rythme</strong></div><p>{temple.entries}</p><p className="quiet-tip"><Check size={15} />{temple.leastCrowded}</p></div><div className="modal-columns"><div><span className="modal-label">À ne pas manquer</span><ul>{temple.highlights.map((highlight) => <li key={highlight}>{highlight}</li>)}</ul></div><div><span className="modal-label">Le bon chemin</span><p>{temple.route}</p><span className="modal-label">Sur place</span><p>{temple.tips}</p></div></div><div className="modal-actions"><button className="primary-button" onClick={onToggle}>{selected ? <><Check size={17} />{t.added}</> : <><Plus size={17} />{t.add}</>}</button><button className="ghost-button" onClick={onMap}><MapPinned size={17} />Voir sur la carte</button></div></div></div></div>;
}

function ActivityModal({ activity, locationState, distance, onClose, onMap, onLocate }: { activity: SiemReapActivity; locationState: "idle" | "locating" | "active" | "denied" | "error"; distance: string | null; onClose: () => void; onMap: () => void; onLocate: () => void }) {
  const directionsUrl = `https://www.google.com/maps/dir/?api=1&destination=${activity.coords.lat},${activity.coords.lng}&travelmode=walking`;
  return <div className="modal-backdrop" role="dialog" aria-modal="true" aria-label={activity.title} onMouseDown={(event) => { if (event.target === event.currentTarget) onClose(); }}><div className="modal-sheet activity-modal"><div className="modal-visual"><img src={activity.image} alt={activity.title} className="temple-image" /><div className="modal-visual-shade" /><button className="modal-close" onClick={onClose} aria-label="Fermer"><X size={19} /></button><div className="modal-title"><span>{activity.category}</span><h2>{activity.title}</h2><small>{activity.detail}</small></div></div><div className="modal-body"><div className="fact-grid"><Fact icon={<Clock3 />} label="Horaires" value={activity.hours} /><Fact icon={<span className="fact-symbol">$</span>} label="Tarif indicatif" value={activity.price} /><Fact icon={<MapPinned />} label="Adresse" value={activity.address} /><Fact icon={<Navigation />} label="Distance GPS" value={distance || "Activez Ma position"} /></div><div className="entry-note activity-note"><div className="entry-note-heading"><Info size={16} /><strong>À savoir</strong></div><p>{activity.text}</p><p className="quiet-tip"><Check size={15} />{activity.practical}</p>{locationState !== "active" && <button className="gps-inline-button" onClick={onLocate}><LocateFixed size={14} />{locationState === "locating" ? "Localisation…" : "Activer Ma position pour mesurer la distance"}</button>}{locationState === "active" && <small className="live-distance-note">Distance calculée depuis votre dernière position GPS.</small>}</div><div className="modal-columns"><div><span className="modal-label">Coordonnées</span><p>{activity.coords.lat.toFixed(4)}° N · {activity.coords.lng.toFixed(4)}° E</p></div><div><span className="modal-label">Repère pratique</span><p>Les horaires et tarifs peuvent varier selon la saison, la météo et le prestataire.</p></div></div><div className="modal-actions"><a className="primary-button" href={directionsUrl} target="_blank" rel="noreferrer"><Navigation size={17} />Itinéraire Google Maps <ExternalLink size={14} /></a><button className="ghost-button" onClick={onMap}><MapPinned size={17} />Voir sur la carte</button><button className="ghost-button" onClick={onClose}>Fermer</button></div></div></div></div>;
}

function Fact({ icon, label, value }: { icon: React.ReactNode; label: string; value: string }) { return <div className="fact"><span>{icon}</span><small>{label}</small><strong>{value}</strong></div>; }

function SelectionDrawer({ selected, onClose, onToggle, onClear, onPrint, t }: { selected: string[]; onClose: () => void; onToggle: (id: string) => void; onClear: () => void; onPrint: () => void; t: Translation }) {
  const chosen = temples.filter((temple) => selected.includes(temple.id));
  return <div className="drawer-backdrop" onMouseDown={(event) => { if (event.target === event.currentTarget) onClose(); }}><aside className="selection-drawer"><div className="drawer-header"><div><span className="eyebrow dark"><span className="eyebrow-line" />Votre itinéraire</span><h2>{t.selection}</h2></div><button className="icon-button" onClick={onClose} aria-label={t.close}><X size={19} /></button></div><div className="drawer-body">{!chosen.length ? <div className="drawer-empty"><ListChecks size={28} /><strong>{t.selectedEmpty}</strong></div> : chosen.map((temple, index) => <div className="selected-item" key={temple.id}><span className="selected-index">0{index + 1}</span><div><strong>{temple.name}</strong><small>{temple.duration} · {temple.light}</small></div><button onClick={() => onToggle(temple.id)} aria-label={`Retirer ${temple.name}`}><X size={15} /></button></div>)}</div><div className="drawer-footer"><div className="drawer-total"><span>Total</span><strong>{chosen.length} temple{chosen.length > 1 ? "s" : ""}</strong></div><button className="primary-button" onClick={onPrint} disabled={!chosen.length}><Download size={16} />{t.print}</button><button className="ghost-button" onClick={onClear} disabled={!chosen.length}>{t.clear}</button></div></aside></div>;
}
