/**
 * Convertit une durée de visite en minutes.
 * Exemples : « 2–3 h » → 150, « 45–75 min » → 60, « 1 h 30 » → 90,
 * « Demi-journée A/R » → 240, « 1 journée » → 480.
 */
export function estimateTempleMinutes(duration: string): number {
  if (/demi-journée/i.test(duration)) return 240;
  if (/journée/i.test(duration)) return 480;
  // Format « 1 h 30 » (heures et minutes)
  const hoursMinutes = duration.match(/(\d+)\s*h\s*(\d{2})\b/i);
  if (hoursMinutes) return Number(hoursMinutes[1]) * 60 + Number(hoursMinutes[2]);
  // Plage « 2–3 h » ou « 45–75 min » : on retient le milieu de la plage
  const range = duration.match(/(\d+(?:[.,]\d+)?)(?:\s*[–-]\s*(\d+(?:[.,]\d+)?))?\s*(h|min)\b/i);
  if (!range) return 30;
  const unit = range[3].toLowerCase() === "h" ? 60 : 1;
  const low = Number(range[1].replace(",", ".")) * unit;
  const high = range[2] ? Number(range[2].replace(",", ".")) * unit : low;
  return Math.round((low + high) / 2);
}
