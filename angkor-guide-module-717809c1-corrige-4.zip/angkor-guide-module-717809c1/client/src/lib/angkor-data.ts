export type Circuit = "petit" | "grand" | "sunset" | "beng" | "plus";

export type Temple = {
  id: string;
  name: string;
  khmer: string;
  circuits: Circuit[];
  period: string;
  king: string;
  cult: string;
  style: string;
  duration: string;
  crowd: string;
  light: string;
  image: string;
  coords: { lat: number; lng: number };
  summary: string;
  entries: string;
  leastCrowded: string;
  highlights: string[];
  route: string;
  tips: string;
  detour?: boolean;
  secondary?: boolean;
};

const commons = (file: string, width = 1000) =>
  `https://commons.wikimedia.org/wiki/Special:FilePath/${encodeURIComponent(file)}?width=${width}`;

export const temples: Temple[] = [
  {
    id: "angkor-wat",
    name: "Angkor Wat",
    khmer: "អង្គរវត្ត",
    circuits: ["petit"],
    period: "c. 1113–1150",
    king: "Suryavarman II",
    cult: "Vishnou → bouddhiste",
    style: "Angkor Wat",
    duration: "2–3 h",
    crowd: "Très élevé",
    light: "5h–7h / 16h–18h",
    image: commons("Angkor_Wat.jpg", 1200),
    coords: { lat: 13.4125, lng: 103.8667 },
    summary: "La silhouette fondatrice du voyage : un monument à parcourir lentement, au-delà de la photo de l’aube.",
    entries: "Quatre gopuras. L’approche monumentale est à l’ouest, par la chaussée et les bassins. L’est permet une entrée bien plus calme.",
    leastCrowded: "Porte est, surtout à l’aube : moins de foule, mais pas de silhouette classique sur le bassin.",
    highlights: ["Galerie du Barattage de la mer de lait", "Bassins nord et reflet du lever", "Bibliothèques et chaussée", "Bakan dès 7h30, épaules et genoux couverts"],
    route: "Pour la carte postale, ouest à l’aube puis boucle nord vers les galeries est. Pour éviter la foule, commencez à l’est.",
    tips: "Contrôlez votre pass avant de rejoindre la chaussée. Chaussures parfois retirées au Bakan. Eau, chapeau et deux heures minimum.",
  },
  {
    id: "bayon",
    name: "Bayon",
    khmer: "បាយ័ន",
    circuits: ["petit"],
    period: "fin XIIe–début XIIIe",
    king: "Jayavarman VII",
    cult: "Bouddhisme mahayana",
    style: "Bayon",
    duration: "45–75 min",
    crowd: "Élevé",
    light: "8h–11h",
    image: commons("Bayon.jpg", 1100),
    coords: { lat: 13.4413, lng: 103.8589 },
    summary: "Un labyrinthe de visages et de bas-reliefs, au cœur d’Angkor Thom.",
    entries: "La plupart des groupes passent par l’est, côté parking d’Angkor Thom. L’entrée sud regarde la route de la porte sud.",
    leastCrowded: "Entrée sud entre 12h et 13h30, quand les groupes déjeunent, ou avant 8h.",
    highlights: ["54 tours et jusqu’à 216 visages", "Bas-reliefs : marché, guerre cham, vie quotidienne", "Le dédale du premier niveau"],
    route: "Faites le socle dans le sens horaire, puis montez progressivement vers les visages.",
    tips: "Les visages changent avec l’angle. Évitez 9h–11h si vous détestez les files.",
  },
  {
    id: "ta-prohm",
    name: "Ta Prohm",
    khmer: "តាព្រហ្ម",
    circuits: ["petit"],
    period: "1186",
    king: "Jayavarman VII",
    cult: "Bouddhiste",
    style: "Bayon",
    duration: "50–80 min",
    crowd: "Élevé",
    light: "Après 15h30",
    image: commons("Ta_Prohm.jpg", 1100),
    coords: { lat: 13.4348, lng: 103.889 },
    summary: "La rencontre spectaculaire entre la pierre, les fromagers et la forêt.",
    entries: "Quatre gopuras. La plupart entrent à l’ouest et sortent à l’est, ou inversement selon le parking du tuk-tuk.",
    leastCrowded: "Gopura est en début d’après-midi, ouest après 16h. Le nord est souvent plus fluide.",
    highlights: ["Fromagers et figuiers étrangleurs", "Inscription : 3 140 villages attachés au temple", "Cours latérales et galeries moins fréquentées"],
    route: "Une boucle sur les passerelles. Utilisez les cours latérales quand le corridor central se bouche.",
    tips: "Meilleur créneau 15h30–17h. Restez une heure : le temple est plus vaste qu’un seul arbre célèbre.",
  },
  {
    id: "banteay-kdei",
    name: "Banteay Kdei",
    khmer: "បន្ទាយក្តី",
    circuits: ["petit"],
    period: "fin XIIe–XIIIe",
    king: "Jayavarman VII",
    cult: "Bouddhiste",
    style: "Bayon",
    duration: "35–55 min",
    crowd: "Faible à moyen",
    light: "Ouverture / fin d’après-midi",
    image: commons("Banteay_Kdei.jpg", 1000),
    coords: { lat: 13.43, lng: 103.8962 },
    summary: "Le cousin plus secret de Ta Prohm, parfait quand la foule sature la boucle.",
    entries: "Axe est-ouest : l’ouest fait face à Ta Prohm et l’est s’ouvre sur Srah Srang.",
    leastCrowded: "Ouest à l’ouverture ou est à midi. Après le lever à Srah Srang, commencez côté est.",
    highlights: ["Monastère aux cellules de moines", "Galeries envahies de végétation", "Atmosphère de ruine sans la cohue"],
    route: "Marchez de porte en porte, environ 40 minutes, sans revenir sur vos pas.",
    tips: "Excellent substitut si Ta Prohm est saturé.",
  },
  {
    id: "srah-srang",
    name: "Srah Srang",
    khmer: "ស្រះស្រង់",
    circuits: ["petit", "sunset"],
    period: "Xe, remanié vers 1200",
    king: "Rajendravarman II / Jayavarman VII",
    cult: "Bassin royal",
    style: "Quai Bayon",
    duration: "20–40 min",
    crowd: "Faible sauf à l’aube",
    light: "Aube et crépuscule",
    image: commons("Srah Srang, Angkor, Camboya, 2013-08-16, DD 02.JPG", 1100),
    coords: { lat: 13.4314, lng: 103.9058 },
    summary: "Un grand bassin royal pour ralentir, respirer et regarder la lumière se poser.",
    entries: "Visite classique sur le débarcadère ouest, avec nāgas et lions. Les rives nord et sud se parcourent à pied.",
    leastCrowded: "Toujours plus calme qu’Angkor Wat. L’aube attire quelques photographes, le coucher reste serein.",
    highlights: ["Bassin royal de 700 × 350 m", "Débarcadère de Jayavarman VII", "Reflets et bord de village"],
    route: "Dix minutes sur le quai, vingt de plus si vous marchez une rive.",
    tips: "Ouvre tôt. Des stands de petit-déjeuner font face à Banteay Kdei.",
  },
  {
    id: "phnom-bakheng",
    name: "Phnom Bakheng",
    khmer: "ភ្នំបាខែង",
    circuits: ["petit", "sunset"],
    period: "c. 889–910",
    king: "Yasovarman I",
    cult: "Shiva",
    style: "Bakheng",
    duration: "60–90 min",
    crowd: "Extrême au coucher",
    light: "Coucher · quota 300",
    image: commons("Phnom_Bakheng.jpg", 1100),
    coords: { lat: 13.4239, lng: 103.8558 },
    summary: "Une pyramide-montagne historique, avec vue sur la forêt et Angkor Wat.",
    entries: "Chemin principal depuis le parking sud, entre Angkor Wat et la porte sud d’Angkor Thom. Escalier en bois au sommet.",
    leastCrowded: "Le matin est vide. Au coucher, soyez au pied vers 15h30–16h : environ 300 personnes au sommet.",
    highlights: ["Ancienne pyramide de Yasodharapura", "Vue sur les tours d’Angkor Wat", "Coucher réglementé sans réservation"],
    route: "Montez régulièrement, installez-vous sur la terrasse ouest et redescendez avec une lampe frontale.",
    tips: "Accès au dernier escalier parfois refusé aux enfants et femmes enceintes. Prévoir Pre Rup en plan B.",
  },
  {
    id: "pre-rup",
    name: "Pre Rup",
    khmer: "ប្រែរូប",
    circuits: ["grand", "sunset"],
    period: "961",
    king: "Rajendravarman II",
    cult: "Shiva",
    style: "Pre Rup",
    duration: "35–55 min",
    crowd: "Moyen au coucher",
    light: "16h30–18h30",
    image: commons("Pre_Rup.jpg", 1100),
    coords: { lat: 13.4353, lng: 103.9206 },
    summary: "La terrasse de latérite où la journée s’achève dans des teintes cuivre.",
    entries: "Les escaliers est donnent l’accès principal. Les faces nord et ouest sont plus silencieuses.",
    leastCrowded: "Arrivez avant 16h30 pour choisir votre point de vue et éviter la vague du coucher.",
    highlights: ["Architecture en gradins", "Brique et latérite dans la lumière rasante", "Panorama ouvert sur la forêt"],
    route: "Faites le tour au sol puis montez par l’est ; gardez la plateforme ouest pour la lumière.",
    tips: "Bonne alternative à Phnom Bakheng, plus simple d’accès et sans quota.",
  },
  {
    id: "preah-khan",
    name: "Preah Khan",
    khmer: "ព្រះខ័ន",
    circuits: ["grand"],
    period: "1191",
    king: "Jayavarman VII",
    cult: "Bouddhiste",
    style: "Bayon",
    duration: "60–90 min",
    crowd: "Faible à moyen",
    light: "Matin",
    image: commons("Preah_Khan.jpg", 1100),
    coords: { lat: 13.4619, lng: 103.8712 },
    summary: "Une ville-temple immense : perspectives, cours et détails à chaque porte.",
    entries: "Axe ouest-est très long. L’entrée ouest est la plus fréquentée ; arrivez tôt pour les galeries calmes.",
    leastCrowded: "Les cours latérales et l’extrémité est offrent une respiration même quand l’axe se remplit.",
    highlights: ["Hall des danseuses", "Galeries imbriquées", "Arbre sur la porte est", "Bâtiment à colonnes unique"],
    route: "Entrez à l’ouest, traversez les cours principales, puis revenez par les galeries latérales.",
    tips: "Prévoir de bonnes chaussures : le parcours est long et le sol inégal.",
  },
  {
    id: "neak-pean",
    name: "Neak Pean",
    khmer: "នាគព័ន្ធ",
    circuits: ["grand"],
    period: "fin XIIe",
    king: "Jayavarman VII",
    cult: "Bouddhiste / thérapeutique",
    style: "Bayon",
    duration: "20–35 min",
    crowd: "Faible",
    light: "Bassin, lumière zénithale",
    image: commons("Neak_Pean.jpg", 1000),
    coords: { lat: 13.4633, lng: 103.8956 },
    summary: "Une île-sanctuaire posée sur l’eau, au bout d’une passerelle aérienne.",
    entries: "Accès par la passerelle depuis le parking. Le temple central s’observe depuis l’extérieur.",
    leastCrowded: "Avant 9h ou après 15h, quand les groupes font le tour du Grand Circuit.",
    highlights: ["Îlot circulaire et nāgas", "Bassins thérapeutiques", "Paysage de réservoir"],
    route: "Prenez la passerelle sans vous presser puis faites le tour du bassin central.",
    tips: "Le niveau d’eau et l’ambiance changent selon la saison.",
  },
  {
    id: "ta-som",
    name: "Ta Som",
    khmer: "តាសោម",
    circuits: ["grand"],
    period: "fin XIIe",
    king: "Jayavarman VII",
    cult: "Bouddhiste",
    style: "Bayon",
    duration: "20–35 min",
    crowd: "Très faible",
    light: "Gopura est + figuier",
    image: commons("Ta_Som.jpg", 1000),
    coords: { lat: 13.4645, lng: 103.9131 },
    summary: "Petit temple à taille humaine, où les racines ont repris possession du gopura est.",
    entries: "Axe est-ouest simple. La porte est est la scène la plus spectaculaire.",
    leastCrowded: "Arrivez avant 9h pour avoir le gopura aux racines presque pour vous.",
    highlights: ["Visage du gopura central", "Figuier étrangleur de la porte est", "Sculptures lisibles sans cohue"],
    route: "Traversez d’ouest en est, puis revenez par le chemin extérieur.",
    tips: "Un arrêt court mais très photogénique ; idéal entre Neak Pean et East Mebon.",
  },
  {
    id: "east-mebon",
    name: "East Mebon",
    khmer: "មេបុណ្យខាងកើត",
    circuits: ["grand"],
    period: "953",
    king: "Rajendravarman II",
    cult: "Shiva",
    style: "Pre Rup",
    duration: "25–40 min",
    crowd: "Faible",
    light: "Éléphants d’angle",
    image: commons("Eastern_Mebon.jpg", 1000),
    coords: { lat: 13.4467, lng: 103.9197 },
    summary: "Un temple-montagne autrefois posé sur une île, gardé par quatre éléphants.",
    entries: "Escalier principal à l’est. Les terrasses et les éléphants se lisent en tournant autour du sanctuaire.",
    leastCrowded: "Le milieu de matinée offre souvent le meilleur compromis lumière / calme.",
    highlights: ["Éléphants aux angles", "Tours en brique", "Perspective sur l’ancien réservoir"],
    route: "Faites le tour de la terrasse inférieure avant de monter par l’est.",
    tips: "La pierre chauffe vite : casquette et eau utiles.",
  },
  {
    id: "baphuon",
    name: "Baphuon",
    khmer: "បាពួន",
    circuits: ["petit"],
    period: "milieu XIe siècle",
    king: "Udayadityavarman II",
    cult: "Shiva",
    style: "Temple-montagne",
    duration: "25–40 min",
    crowd: "Moyen",
    light: "Matin",
    image: commons("Baphuon.jpg", 1000),
    coords: { lat: 13.4455, lng: 103.8553 },
    summary: "Une longue chaussée mène à ce temple-montagne posé au cœur d’Angkor Thom.",
    entries: "Accès par la chaussée ouest, puis montée progressive sur les terrasses.",
    leastCrowded: "Avant 8h30 ou en fin de matinée.",
    highlights: ["Chaussée surélevée", "Relief du Bouddha couché", "Vues sur Angkor Thom"],
    route: "À placer entre la Terrasse des Éléphants et le Bayon, sans détour important.",
    tips: "Un arrêt court mais très lisible pour comprendre le temple-montagne.",
    secondary: true,
  },
  {
    id: "phimeanakas",
    name: "Phimeanakas",
    khmer: "ភិមានអាកាស",
    circuits: ["petit"],
    period: "fin Xe–début XIe siècle",
    king: "Rajendravarman II / Suryavarman I",
    cult: "Hindou",
    style: "Temple-montagne",
    duration: "15–25 min",
    crowd: "Faible",
    light: "Matin doux",
    image: commons("Phimeanakas.jpg", 1000),
    coords: { lat: 13.4481, lng: 103.8553 },
    summary: "Un petit sanctuaire discret dans l’enceinte royale d’Angkor Thom.",
    entries: "Depuis l’enceinte du Palais royal, par les sentiers ombragés.",
    leastCrowded: "Entre deux groupes au Bayon, quand la cour royale se vide.",
    highlights: ["Terrasses de grès", "Ancien bassin royal", "Atmosphère ombragée"],
    route: "Combinez-le avec la Terrasse des Éléphants et le Baphuon.",
    tips: "Les vestiges sont plus subtils que monumentaux : gardez 20 minutes.",
    secondary: true,
  },
  {
    id: "terrace-elephants",
    name: "Terrasse des Éléphants",
    khmer: "ព្រះលានដំរី",
    circuits: ["petit"],
    period: "fin XIIe siècle",
    king: "Jayavarman VII",
    cult: "Cour royale",
    style: "Bas-reliefs",
    duration: "15–25 min",
    crowd: "Moyen",
    light: "Matin ou fin d’après-midi",
    image: commons("Terrace_of_the_Elephants.jpg", 1000),
    coords: { lat: 13.4461, lng: 103.8595 },
    summary: "La tribune cérémonielle d’Angkor Thom, bordée d’éléphants et de nagas.",
    entries: "Longue façade le long de la place royale, entre le Bayon et la porte Est.",
    leastCrowded: "Le long de l’extrémité nord, loin des groupes du Bayon.",
    highlights: ["Éléphants sculptés", "Place royale", "Terrasse du Roi lépreux à proximité"],
    route: "Marchez sur la façade après le Bayon, puis rejoignez le Baphuon.",
    tips: "À parcourir lentement : les détails se lisent mieux depuis la place.",
    secondary: true,
  },
  {
    id: "terrace-leper-king",
    name: "Terrasse du Roi lépreux",
    khmer: "ព្រះលានស្តេចគម្លង់",
    circuits: ["petit"],
    period: "XIIe siècle",
    king: "Jayavarman VII",
    cult: "Symbolique royale",
    style: "Bas-reliefs",
    duration: "15–20 min",
    crowd: "Faible à moyen",
    light: "Matin",
    image: commons("Terrace_of_the_Leper_King.jpg", 1000),
    coords: { lat: 13.447, lng: 103.859 },
    summary: "Un mur sculpté en profondeur, plus secret que la terrasse voisine.",
    entries: "Accès par la place royale, côté nord de la Terrasse des Éléphants.",
    leastCrowded: "Presque toujours plus calme que la façade des éléphants.",
    highlights: ["Double paroi sculptée", "Figures enchevêtrées", "Passage couvert"],
    route: "Faites le tour par le passage arrière avant de reprendre la place royale.",
    tips: "Lampe de téléphone utile dans les parties les plus ombragées.",
    secondary: true,
  },
  {
    id: "thommanon",
    name: "Thommanon",
    khmer: "ធម្មនន្ទ",
    circuits: ["petit"],
    period: "début XIIe siècle",
    king: "Suryavarman II",
    cult: "Shiva / Vishnou",
    style: "Angkor Wat",
    duration: "20–30 min",
    crowd: "Faible",
    light: "Matin",
    image: commons("Thommanon.jpg", 1000),
    coords: { lat: 13.4461, lng: 103.8715 },
    summary: "Un petit temple élégant, restauré et souvent délaissé par les groupes.",
    entries: "Installé face à Chau Say Tevoda, au bord de la route est d’Angkor Thom.",
    leastCrowded: "Avant 9h ou entre deux passages de tuk-tuk.",
    highlights: ["Frontons bien conservés", "Apsaras fines", "Format compact"],
    route: "Arrêt naturel sur la route entre la porte de la Victoire et Ta Prohm.",
    tips: "Parfait pour une pause de 20 minutes entre deux sites majeurs.",
    secondary: true,
  },
  {
    id: "chau-say-tevoda",
    name: "Chau Say Tevoda",
    khmer: "ចៅសាយទេវតា",
    circuits: ["petit"],
    period: "début XIIe siècle",
    king: "Suryavarman II",
    cult: "Shiva / Vishnou",
    style: "Angkor Wat",
    duration: "20–30 min",
    crowd: "Faible",
    light: "Matin ou fin de journée",
    image: commons("Chau_Say_Tevoda.jpg", 1000),
    coords: { lat: 13.4453, lng: 103.8714 },
    summary: "Le petit temple jumeau de Thommanon, posé dans un écrin de verdure.",
    entries: "Accès direct depuis le parking commun avec Thommanon.",
    leastCrowded: "En milieu de matinée, quand les cars continuent vers Ta Prohm.",
    highlights: ["Tours restaurées", "Douves végétalisées", "Bas-reliefs de devatas"],
    route: "Visitez-le avec Thommanon en une seule halte de 45 minutes.",
    tips: "Ne cherchez pas un grand parcours : l’intérêt est dans les détails.",
    secondary: true,
  },
  {
    id: "krol-ko",
    name: "Krol Ko",
    khmer: "ក្រោលគោ",
    circuits: ["grand"],
    period: "fin XIIe siècle",
    king: "Jayavarman VII",
    cult: "Bouddhiste",
    style: "Bayon",
    duration: "15–25 min",
    crowd: "Très faible",
    light: "Matin",
    image: commons("Krol_Ko.jpg", 1000),
    coords: { lat: 13.462, lng: 103.9015 },
    summary: "Un petit sanctuaire calme sur la branche nord du Grand Circuit.",
    entries: "À quelques minutes de Neak Pean, par la route qui rejoint Ta Som.",
    leastCrowded: "La plupart des visiteurs le dépassent : calme presque garanti.",
    highlights: ["Fronton de Vishnou", "Douves arborées", "Format intime"],
    route: "Ajoutez-le entre Neak Pean et Ta Som si vous avez 20 minutes.",
    tips: "Un détour facile, surtout pour une pause loin des cars.",
    secondary: true,
  },
  {
    id: "ta-nei",
    name: "Ta Nei",
    khmer: "តានៃ",
    circuits: ["grand"],
    period: "fin XIIe siècle",
    king: "Jayavarman VII",
    cult: "Bouddhiste",
    style: "Bayon",
    duration: "25–40 min",
    crowd: "Très faible",
    light: "Après-midi",
    image: commons("Ta_Nei.jpg", 1000),
    coords: { lat: 13.453, lng: 103.919 },
    summary: "Une ruine forestière à l’écart, pour retrouver le silence de l’ancien Angkor.",
    entries: "Piste secondaire depuis la route de Ta Keo, accès parfois irrégulier selon la saison.",
    leastCrowded: "En début d’après-midi, quand les grands sites se remplissent.",
    highlights: ["Galeries envahies de racines", "Petite échelle", "Forêt dense"],
    route: "Demandez à votre chauffeur de prévoir l’accès avant de rejoindre East Mebon.",
    tips: "Chaussures fermées recommandées ; le sol peut être boueux.",
    secondary: true,
  },
  {
    id: "bat-chum",
    name: "Bat Chum",
    khmer: "បាតជុំ",
    circuits: ["grand"],
    period: "milieu Xe siècle",
    king: "Rajendravarman II",
    cult: "Bouddhiste",
    style: "Brique",
    duration: "15–25 min",
    crowd: "Très faible",
    light: "Matin doux",
    image: commons("Bat_Chum.jpg", 1000),
    coords: { lat: 13.4235, lng: 103.906 },
    summary: "Trois petites tours de brique au sud de Srah Srang, simples et silencieuses.",
    entries: "À courte distance de la route entre Srah Srang et East Mebon.",
    leastCrowded: "Toute la journée hors passage d’un groupe organisé.",
    highlights: ["Tours en brique", "Inscription ancienne", "Rizières proches"],
    route: "À combiner avec Srah Srang si vous préférez un détour court au coucher.",
    tips: "Le site est peu ombragé : prévoyez eau et chapeau.",
    secondary: true,
  },
  {
    id: "phnom-krom",
    name: "Phnom Krom",
    khmer: "ភ្នំក្រោម",
    circuits: ["sunset"],
    period: "fin IXe–début Xe",
    king: "Yasovarman I",
    cult: "Trimūrti",
    style: "Bakheng",
    duration: "45–75 min",
    crowd: "Faible",
    light: "Coucher sur le Tonlé Sap",
    image: commons("Prasat_Phnom_Krom.jpg", 1100),
    coords: { lat: 13.2853, lng: 103.8126 },
    summary: "Le grand ciel du Tonlé Sap, loin de la foule des deux boucles centrales.",
    entries: "Route en lacets jusqu’au sommet, puis plateforme ouverte au sud-ouest.",
    leastCrowded: "Arrivez 30 minutes avant le coucher : l’endroit reste nettement plus calme que Bakheng.",
    highlights: ["Trois sanctuaires sur la crête", "Plaine et Tonlé Sap", "Lumière très ouverte"],
    route: "Montez directement au sanctuaire puis marchez vers le bord sud-ouest.",
    tips: "Prévoir un retour de nuit et vérifier les horaires d’accès au site.",
  },
  {
    id: "beng-mealea",
    name: "Beng Mealea",
    khmer: "បេងមាលា",
    circuits: ["beng"],
    period: "Début XIIe",
    king: "Souvent Suryavarman II",
    cult: "Vishnou, puis mixte",
    style: "Angkor Wat",
    duration: "60–90 min",
    crowd: "Faible hors 9h–11h",
    light: "Juste après 7h30",
    image: commons("Beng_Mealea.jpg", 1200),
    coords: { lat: 13.4756, lng: 104.2267 },
    summary: "La grande échappée hors parc : une ruine enveloppée de jungle, à vivre en demi-journée.",
    entries: "Passerelles de bois et parcours au sol autour du sanctuaire central.",
    leastCrowded: "Avant 9h, avant l’arrivée des excursions depuis Siem Reap.",
    highlights: ["Galeries effondrées", "Racines et blocs de grès", "Échelle monumentale d’Angkor Wat"],
    route: "Faites d’abord la boucle de bois, puis revenez dans les cours latérales.",
    tips: "Inclus au pass Angkor ou billet distinct de 10 USD selon les conditions en vigueur.",
  },
  {
    id: "banteay-srei",
    name: "Banteay Srei",
    khmer: "បន្ទាយស្រី",
    circuits: ["plus"],
    period: "967",
    king: "Yajnavaraha",
    cult: "Shiva",
    style: "Banteay Srei",
    duration: "45–70 min",
    crowd: "Moyen",
    light: "Matin, grès rose",
    image: commons("Banteay_Srei.jpg", 1200),
    coords: { lat: 13.5989, lng: 103.9633 },
    summary: "La finesse du grès rose, à combiner avec une route vers le nord.",
    entries: "Axe est-ouest compact, musée et douves avant le sanctuaire.",
    leastCrowded: "Avant 9h ou après 15h30 ; la lumière du matin révèle les détails.",
    highlights: ["Frontons sculptés", "Dvarapalas et apsaras", "Pierre rose très fine"],
    route: "Musée, douves, puis tour lente des trois enceintes.",
    tips: "À associer à Kbal Spean si vous avez une journée complète.",
  },
  {
    id: "roluos",
    name: "Roluos",
    khmer: "រលួស · ហរិហរាល័យ",
    circuits: ["plus"],
    period: "Fin IXe",
    king: "Indravarman I / Yasovarman I",
    cult: "Hindou",
    style: "Preah Ko / Bakong",
    duration: "2–3 h le groupe",
    crowd: "Faible",
    light: "Bakong au petit matin",
    image: commons("Bakong.jpg", 1100),
    coords: { lat: 13.3359, lng: 103.9741 },
    summary: "Les premiers grands temples de la capitale khmère, plus ruraux et plus silencieux.",
    entries: "Trois sites séparés de quelques kilomètres : Preah Ko, Bakong et Lolei.",
    leastCrowded: "Bakong tôt le matin, puis Preah Ko avant les groupes.",
    highlights: ["Tours en brique de Preah Ko", "Pyramide de Bakong", "Paysage de rizières"],
    route: "Preah Ko → Bakong → Lolei, en gardant le temps de marcher autour des douves.",
    tips: "Une excellente demi-journée si vous souhaitez sortir de la route classique.",
  },
  {
    id: "kbal-spean",
    name: "Kbal Spean",
    khmer: "ក្បាលស្ពាន",
    circuits: ["plus"],
    period: "XIe–XIIe",
    king: "Rois khmers successifs",
    cult: "Shiva / lingas de rivière",
    style: "Sculptures rupestres",
    duration: "Demi-journée A/R",
    crowd: "Faible",
    light: "Saison sèche, eau claire",
    image: commons("Kbal_Spean.jpg", 1100),
    coords: { lat: 13.6865, lng: 104.0263 },
    summary: "Une marche en forêt vers une rivière sculptée, à réserver aux journées actives.",
    entries: "Sentier forestier d’environ 1,5 km, montée modérée jusqu’au lit de la rivière.",
    leastCrowded: "Ouverture du site et jours de semaine hors haute saison.",
    highlights: ["Lingas dans le lit de la rivière", "Vishnou couché", "Cascade selon la saison"],
    route: "Marchez jusqu’au cours d’eau, puis descendez le long des sculptures vers la cascade.",
    tips: "Chaussures fermées, eau et prudence sur les rochers mouillés.",
  },
];

export const petitRoute = [
  { lat: 13.4125, lng: 103.8667 }, { lat: 13.4239, lng: 103.8558 },
  { lat: 13.4413, lng: 103.8589 }, { lat: 13.4464, lng: 103.8583 },
  { lat: 13.4467, lng: 103.8774 }, { lat: 13.4446, lng: 103.8823 },
  { lat: 13.4348, lng: 103.889 }, { lat: 13.4300, lng: 103.8962 },
  { lat: 13.4314, lng: 103.9058 }, { lat: 13.4196, lng: 103.8996 },
  { lat: 13.4125, lng: 103.8667 },
];

export const grandRoute = [
  { lat: 13.4536, lng: 103.8590 }, { lat: 13.4619, lng: 103.8712 },
  { lat: 13.4633, lng: 103.8956 }, { lat: 13.4645, lng: 103.9131 },
  { lat: 13.4467, lng: 103.9197 }, { lat: 13.4353, lng: 103.9206 },
];

export const circuitMeta: Record<Circuit, { label: string; short: string; description: string; tone: string }> = {
  petit: { label: "Petit circuit", short: "Boucle essentielle", description: "Les monuments iconiques, de l’aube aux racines de Ta Prohm.", tone: "jade" },
  grand: { label: "Grand circuit", short: "Boucle des bassins", description: "De Preah Khan à Pre Rup, avec plus d’espace entre les groupes.", tone: "terracotta" },
  sunset: { label: "Couchers de soleil", short: "4 points de vue", description: "Bakheng, Pre Rup, Srah Srang et Phnom Krom : choisir selon l’envie.", tone: "gold" },
  beng: { label: "Beng Mealea", short: "Jungle à l’est", description: "Une demi-journée hors du parc central, incluse au pass Angkor selon les conditions.", tone: "forest" },
  plus: { label: "Aller plus loin", short: "Une autre journée", description: "Banteay Srei, Roluos, Kbal Spean et les détours qui méritent leur temps.", tone: "blue" },
};

export const circuitOrder: Circuit[] = ["petit", "grand", "sunset", "beng", "plus"];

export const practicalPanels = {
  eat: [
    { title: "Sur la route", text: "Autour de Srah Srang et Banteay Kdei, les stands s’installent tôt. Pour un vrai déjeuner, prévoyez un arrêt à Siem Reap ou au bord de la route principale.", tag: "Petit-déjeuner" },
    { title: "À l’intérieur du parc", text: "Gardez de l’eau et quelques fruits dans le tuk-tuk. Les restaurants des abords sont pratiques, mais les prix montent près des portes les plus fréquentées.", tag: "À emporter" },
    { title: "Le soir", text: "Pub Street n’est pas la seule option : le quartier Wat Bo offre des tables plus calmes et une belle transition après les temples.", tag: "Siem Reap" },
  ],
  practical: [
    { title: "Billet", text: "Tarifs et règles rédigés en octobre 2026 : ils peuvent changer. Confirmez-les sur Angkor Enterprise le jour du départ. Le pass 1, 3 ou 7 jours couvre le parc selon les conditions en vigueur.", tag: "À vérifier" },
    { title: "Transport", text: "Tuk-tuk pour la souplesse, vélo pour les courtes distances, voiture climatisée pour Beng Mealea et les détours nord.", tag: "Déplacements" },
    { title: "Tenue", text: "Épaules et genoux couverts dans les espaces sacrés. Chaussures fermées, chapeau, crème solaire et eau changent vraiment la journée.", tag: "Confort" },
    { title: "Accessibilité", text: "Les sites sont en pierre et en latérite, avec marches, seuils et pavés irréguliers. Les parcours sont difficiles en fauteuil roulant : renseignez-vous sur les accès avant de partir et prévoyez de l’aide pour les escaliers.", tag: "PMR" },
    { title: "Sécurité", text: "Convenez du prix du tuk-tuk avant de monter. Si vous louez une moto, portez un casque et un permis valide. Dans les campagnes, restez sur les chemins balisés et gardez vos papiers sur vous.", tag: "Sécurité" },
    { title: "Drones et photo", text: "L’usage d’un drone dans le parc est encadré et demande une autorisation préalable. À vérifier avant le départ auprès d’Angkor Enterprise, car les règles peuvent changer.", tag: "À vérifier" },
  ],
  advice: [
    { title: "Commencer tôt", text: "Le lever d’Angkor Wat est spectaculaire mais facultatif. Une entrée à 7h30 peut offrir une meilleure journée que cinq heures de foule.", tag: "Rythme" },
    { title: "Se laisser du temps", text: "Deux temples bien vécus valent mieux que six arrêts photographiés depuis le parking. Laissez une marge pour les détours et la chaleur.", tag: "Visite" },
    { title: "Plan B météo", text: "En cas de ciel couvert, gardez les galeries, Bayon et Ta Prohm. La lumière douce fonctionne souvent mieux que le soleil dur.", tag: "Flexibilité" },
  ],
};

export const languages = [
  { value: "fr", label: "Français" }, { value: "en", label: "English" },
  { value: "es", label: "Español" }, { value: "de", label: "Deutsch" },
  { value: "it", label: "Italiano" }, { value: "zh", label: "中文" },
  { value: "ja", label: "日本語" }, { value: "km", label: "ខ្មែរ" },
];

export const translations: Record<string, Record<string, string>> = {
  fr: { brandSub: "Parc archéologique · Siem Reap", lang: "Langue", selection: "Ma sélection", heroKicker: "Guide de terrain · 2026", heroTitle: "Composez votre journée à Angkor.", heroLead: "Les temples essentiels, les détours qui valent le coup et les lumières à viser — réunis dans un compagnon de route simple à emporter.", map: "Repères sur la carte", temples: "Temples à votre rythme", eat: "Faire une pause", practical: "Infos pratiques", advice: "Conseils de visite", beyond: "Aller plus loin", view: "Voir la fiche", add: "Ajouter", added: "Ajouté", clear: "Vider", print: "Imprimer la sélection", close: "Fermer", selectedEmpty: "Votre sélection est vide. Ajoutez des temples pour construire une journée.", fieldNote: "Note de terrain", mapIntro: "Filtrez un circuit, repérez les sites et ouvrez une fiche directement depuis la carte.", footer: "Guide indépendant · données de travail 2025–2026 · vérifiez horaires, billets et quotas le jour J." },
  en: { brandSub: "Archaeological park · Siem Reap", lang: "Language", selection: "My selection", heroKicker: "Field guide · 2026", heroTitle: "Compose your day at Angkor.", heroLead: "Essential temples, worthwhile detours and the light to chase — gathered in a practical companion for the road.", map: "Map notes", temples: "Temples at your pace", eat: "Take a break", practical: "Practical info", advice: "Visit advice", beyond: "Go further", view: "Open guide", add: "Add", added: "Added", clear: "Clear", print: "Print selection", close: "Close", selectedEmpty: "Your selection is empty. Add temples to build a day.", fieldNote: "Field note", mapIntro: "Filter a circuit, locate the sites and open a temple sheet right from the map.", footer: "Independent guide · working data 2025–2026 · verify hours, tickets and quotas on the day." },
  es: { brandSub: "Parque arqueológico · Siem Reap", lang: "Idioma", selection: "Mi selección", heroKicker: "Guía de campo · 2026", heroTitle: "Compón tu día en Angkor.", heroLead: "Templos esenciales, desvíos que merecen la pena y la luz que conviene buscar, en un compañero de ruta.", map: "Mapa de sitios", temples: "Templos a tu ritmo", eat: "Hacer una pausa", practical: "Información práctica", advice: "Consejos", beyond: "Más lejos", view: "Ver ficha", add: "Añadir", added: "Añadido", clear: "Vaciar", print: "Imprimir selección", close: "Cerrar", selectedEmpty: "Tu selección está vacía. Añade templos para preparar el día.", fieldNote: "Nota de campo", mapIntro: "Filtra un circuito, localiza los sitios y abre una ficha desde el mapa.", footer: "Guía independiente · datos de trabajo 2025–2026 · comprueba horarios, entradas y cupos el mismo día." },
  de: { brandSub: "Archäologischer Park · Siem Reap", lang: "Sprache", selection: "Meine Auswahl", heroKicker: "Feldführer · 2026", heroTitle: "Gestalte deinen Tag in Angkor.", heroLead: "Wichtige Tempel, lohnende Abstecher und das beste Licht – kompakt für unterwegs.", map: "Kartenhinweise", temples: "Tempel in deinem Tempo", eat: "Pause machen", practical: "Praktisches", advice: "Besuchstipps", beyond: "Weiter hinaus", view: "Karte öffnen", add: "Hinzufügen", added: "Hinzugefügt", clear: "Leeren", print: "Auswahl drucken", close: "Schließen", selectedEmpty: "Deine Auswahl ist leer. Füge Tempel für deinen Tag hinzu.", fieldNote: "Feldnotiz", mapIntro: "Runde filtern, Orte finden und das Datenblatt direkt auf der Karte öffnen.", footer: "Unabhängiger Guide · Arbeitsdaten 2025–2026 · Zeiten, Tickets und Quoten am Tag prüfen." },
  km: { brandSub: "ឧទ្យានបុរាណវិទ្យា · សៀមរាប", lang: "ភាសា", selection: "ជម្រើសរបស់ខ្ញុំ", heroKicker: "មគ្គុទ្ទេសក៍ · ២០២៦", heroTitle: "រៀបចំថ្ងៃរបស់អ្នកនៅអង្គរ។", heroLead: "ប្រាសាទសំខាន់ៗ ផ្លូវបន្ថែមដែលគួរទៅ និងពេលវេលាដែលមានពន្លឺស្អាត — នៅក្នុងមគ្គុទ្ទេសក៍ងាយយកតាមខ្លួន។", map: "ចំណុចលើផែនទី", temples: "ប្រាសាទតាមល្បឿនរបស់អ្នក", eat: "សម្រាក", practical: "ព័ត៌មានជាក់ស្តែង", advice: "គន្លឹះទស្សនា", beyond: "ទៅឆ្ងាយជាងនេះ", view: "មើលព័ត៌មាន", add: "បន្ថែម", added: "បានបន្ថែម", clear: "លុបចេញ", print: "បោះពុម្ពជម្រើស", close: "បិទ", selectedEmpty: "មិនទាន់មានជម្រើសទេ។ បន្ថែមប្រាសាទដើម្បីរៀបចំថ្ងៃរបស់អ្នក។", fieldNote: "កំណត់ត្រាតាមផ្លូវ", mapIntro: "ជ្រើសរើសផ្លូវ ស្វែងរកទីតាំង និងបើកព័ត៌មានប្រាសាទដោយផ្ទាល់ពីផែនទី។", footer: "មគ្គុទ្ទេសក៍ឯករាជ្យ · ទិន្នន័យការងារ ២០២៥–២០២៦ · សូមពិនិត្យម៉ោង សំបុត្រ និងកំណត់ចំនួននៅថ្ងៃទៅទស្សនា។" },
};

export const getTemple = (id: string) => temples.find((temple) => temple.id === id);
export const getImage = (temple: Temple, width = 1000) => temple.image.replace(/width=\d+/, `width=${width}`);

export type ItineraryDay = {
  day: number;
  title: string;
  subtitle: string;
  temples: Temple[];
  hours: string;
  distance: string;
  note: string;
  optionalTemples?: Temple[];
};

const byId = (id: string) => temples.find((temple) => temple.id === id)!;

export const itineraryPresets: Record<number, ItineraryDay[]> = {
  1: [
    { day: 1, title: "Les essentiels d’Angkor", subtitle: "Aube, visages et jungle", temples: [byId("angkor-wat"), byId("bayon"), byId("ta-prohm"), byId("srah-srang")], hours: "7–9 h", distance: "17 km", note: "Le meilleur condensé pour une première journée, sans chercher à tout voir.", optionalTemples: [byId("baphuon"), byId("terrace-elephants"), byId("thommanon")] },
  ],
  2: [
    { day: 1, title: "Les icônes de la petite boucle", subtitle: "Aube, visages et jungle", temples: [byId("angkor-wat"), byId("bayon"), byId("ta-prohm"), byId("srah-srang")], hours: "7–9 h", distance: "17 km", note: "Commencez tôt, puis gardez Ta Prohm pour la lumière de l’après-midi.", optionalTemples: [byId("baphuon"), byId("phimeanakas"), byId("terrace-elephants"), byId("terrace-leper-king"), byId("thommanon"), byId("chau-say-tevoda")] },
    { day: 2, title: "Les bassins et la pierre chaude", subtitle: "Grand circuit, plus calme", temples: [byId("preah-khan"), byId("neak-pean"), byId("ta-som"), byId("east-mebon"), byId("pre-rup")], hours: "6–8 h", distance: "26 km", note: "Une journée plus étirée : pauses régulières et coucher à Pre Rup en option.", optionalTemples: [byId("krol-ko"), byId("ta-nei"), byId("bat-chum")] },
  ],
  3: [
    { day: 1, title: "Angkor Wat & Angkor Thom", subtitle: "Les fondations du voyage", temples: [byId("angkor-wat"), byId("bayon"), byId("ta-prohm")], hours: "6–8 h", distance: "12 km", note: "Un rythme doux pour garder du temps dans les galeries et les cours.", optionalTemples: [byId("baphuon"), byId("phimeanakas"), byId("terrace-elephants"), byId("terrace-leper-king")] },
    { day: 2, title: "Le grand circuit en profondeur", subtitle: "Bassins, portes et latérite", temples: [byId("preah-khan"), byId("neak-pean"), byId("ta-som"), byId("east-mebon"), byId("pre-rup")], hours: "6–8 h", distance: "26 km", note: "La journée des perspectives longues, avec Pre Rup pour finir.", optionalTemples: [byId("krol-ko"), byId("ta-nei"), byId("bat-chum")] },
    { day: 3, title: "La jungle ou le grès rose", subtitle: "Une échappée hors des boucles", temples: [byId("beng-mealea"), byId("banteay-srei"), byId("roluos")], hours: "7–10 h", distance: "Selon l’option", note: "Beng Mealea pour la jungle, Banteay Srei pour les détails : choisissez votre humeur." },
  ],
};

export const getItinerary = (days: number) => itineraryPresets[Math.min(3, Math.max(1, days))];

export type SiemReapActivity = {
  id: string;
  number: string;
  category: string;
  title: string;
  text: string;
  detail: string;
  bestTime: string;
  hours: string;
  price: string;
  address: string;
  coords: { lat: number; lng: number };
  practical: string;
  image: string;
  tone: "jade" | "terracotta" | "gold" | "blue";
};

export const siemReapActivities: SiemReapActivity[] = [
  { id: "markets", number: "01", category: "À goûter", title: "Manger comme un local", text: "Soupes fumantes, herbes fraîches et marchés qui s’éveillent avant la chaleur.", detail: "Phsar Chas · cuisine khmère · pause fraîche", bestTime: "Matin ou soir", hours: "06:00–22:00", price: "Repas : 2–8 USD", address: "Phsar Chas, centre-ville de Siem Reap", coords: { lat: 13.3546, lng: 103.8558 }, practical: "Privilégiez les stands fréquentés par les habitants et gardez de petites coupures.", image: "https://files.manuscdn.com/search-media/310519663910403859/fwGF5gMQc7JdGyXzct3J9N/3xbuM3xb4iM9cJQxXqxPkZ.jpg", tone: "terracotta" },
  { id: "crafts", number: "02", category: "À comprendre", title: "Voir les gestes du savoir-faire", text: "La soie, le bois et la laque racontent un autre visage du Cambodge, patient et contemporain.", detail: "Artisanat · ateliers · objets choisis", bestTime: "Après-midi", hours: "08:00–18:00", price: "Entrée libre · ateliers selon formule", address: "Artisans Angkor, Stung Thmey Street", coords: { lat: 13.3601, lng: 103.8568 }, practical: "Comptez 45 minutes pour la visite et demandez si une démonstration est en cours.", image: "https://files.manuscdn.com/search-media/310519663910403859/fwGF5gMQc7JdGyXzct3J9N/u9KsHAG2T4FsZ8wghre7bd.jpg", tone: "gold" },
  { id: "tonle-sap", number: "03", category: "À prendre le large", title: "Prendre le large sur le Tonlé Sap", text: "Un horizon d’eau, des villages flottants et un ciel qui change d’échelle à mesure que l’on s’éloigne.", detail: "Kampong Phluk · barque · lumière ouverte", bestTime: "Fin d’après-midi", hours: "07:00–17:30", price: "Bateau : env. 20–35 USD", address: "Embarcadère de Kampong Phluk, à env. 30 km", coords: { lat: 13.239, lng: 104.065 }, practical: "La durée et le paysage varient selon la saison des eaux ; partez avec une agence ou un batelier identifié.", image: "https://files.manuscdn.com/search-media/310519663910403859/fwGF5gMQc7JdGyXzct3J9N/LGX5XBfUqX4KARBPKTozS5.jpg", tone: "blue" },
  { id: "wellbeing", number: "04", category: "À ralentir", title: "S’offrir une parenthèse", text: "Massage, respiration ou simple promenade au bord de la rivière : le séjour a aussi besoin de silence.", detail: "Rivière · spa · jardin ombragé", bestTime: "Heure chaude", hours: "09:00–22:00", price: "Massage : env. 15–60 USD", address: "Quartier Wat Bo et jardins au bord de la rivière", coords: { lat: 13.358, lng: 103.859 }, practical: "Réservez les soins en fin de matinée et confirmez la durée ainsi que le prix avant de commencer.", image: "https://files.manuscdn.com/search-media/310519663910403859/fwGF5gMQc7JdGyXzct3J9N/HXodVRdNkkzfE6qcXjqBj5.jpg", tone: "jade" },
  { id: "evening", number: "05", category: "À vivre", title: "Sortir quand la ville s’allume", text: "Une scène douce après les temples : musique, petites tables et ruelles animées sans se presser.", detail: "Night Market · musique · terrasse", bestTime: "Après 18h", hours: "17:00–00:00", price: "Entrée libre · boissons dès 2 USD", address: "Angkor Night Market et Pub Street", coords: { lat: 13.3532, lng: 103.854 }, practical: "Le quartier est très animé : marchez quelques rues au-delà de Pub Street pour une ambiance plus calme.", image: "https://files.manuscdn.com/search-media/310519663910403859/fwGF5gMQc7JdGyXzct3J9N/er9TVgcsxMPXtHGAa46myE.jpg", tone: "terracotta" },
  { id: "countryside", number: "06", category: "À parcourir", title: "Rouler dans la campagne", text: "À vélo ou en tuk-tuk, les chemins autour de Siem Reap révèlent les rizières, les pagodes et le quotidien.", detail: "Rizières · pagodes · villages", bestTime: "Aube ou fin de journée", hours: "06:00–18:00", price: "Vélo : 5–12 USD · tuk-tuk selon trajet", address: "Chemins ruraux à l’ouest et au nord de Siem Reap", coords: { lat: 13.352, lng: 103.82 }, practical: "Partez avec de l’eau, demandez l’état des chemins et évitez les pistes isolées après la tombée du jour.", image: "https://files.manuscdn.com/search-media/310519663910403859/fwGF5gMQc7JdGyXzct3J9N/ZaqUiraEBtA5WsuNgNvGMk.jpeg", tone: "jade" },
];

export type WeatherSnapshot = {
  temperature: number;
  feelsLike: number;
  condition: string;
  rainChance: number;
  humidity: number;
  wind: number;
  source: "local" | "demo";
};

export const fallbackWeather: WeatherSnapshot = {
  temperature: 31,
  feelsLike: 35,
  condition: "Ciel partiellement nuageux",
  rainChance: 20,
  humidity: 68,
  wind: 9,
  source: "demo",
};

export const hourlyRecommendations = [
  { start: 5, end: 8, label: "Aube", title: "Pour la lumière douce", sites: "Angkor Wat · Srah Srang", text: "Partez tôt pour les reflets et les longues perspectives. Prenez un petit-déjeuner après la première visite." },
  { start: 8, end: 11, label: "Matin", title: "Pour les galeries", sites: "Bayon · Preah Khan · Banteay Srei", text: "La lumière reste lisible et la chaleur monte encore doucement : privilégiez les reliefs et les cours couvertes." },
  { start: 11, end: 15, label: "Chaleur", title: "Pour ralentir", sites: "Neak Pean · musée · pause", text: "Gardez les longues marches pour plus tard. Hydratez-vous, déjeunez à l’ombre et choisissez un site compact." },
  { start: 15, end: 18, label: "Après-midi", title: "Pour les racines", sites: "Ta Prohm · Pre Rup · Phnom Bakheng", text: "La lumière descend et les textures ressortent. C’est le bon moment pour la jungle et les terrasses." },
  { start: 18, end: 24, label: "Soir", title: "Pour récupérer", sites: "Siem Reap · Wat Bo", text: "Après le coucher, rentrez sans vous presser. Gardez de l’énergie pour le lendemain plutôt que d’ajouter un temple." },
];

export const weatherRecommendation = (hour: number, weather: WeatherSnapshot) => {
  const base = hourlyRecommendations.find((item) => hour >= item.start && hour < item.end) || hourlyRecommendations[0];
  if (weather.rainChance >= 55) return { ...base, title: "Pour composer avec les averses", text: "Les galeries couvertes et les visites courtes sont vos alliées. Gardez une enveloppe de temps pour attendre une éclaircie." };
  if (weather.feelsLike >= 36 && hour >= 10 && hour < 16) return { ...base, title: "Pour éviter le pic de chaleur", text: "Restez à l’ombre entre 10h et 16h : pause longue, musée ou temple compact avant de reprendre la boucle." };
  return base;
};
